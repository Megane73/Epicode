# Esercizio 1
n_studenti=25

# Esercizio 2
print (n_studenti)

# Esercizio 3
n_studenti2 = n_studenti +3

# Esercizio 4
n_studentiTot = n_studenti + n_studenti2
print (n_studentiTot)

# Esercizio 5
nome = "Epicode"
print (nome)

# Esercizio 6
x = 10
y = (x+2)*3
print (y)

# Esercizio 7
str1 = "Windows"
str2 = "Excel"
str3 = "Powerpoint"
str4 = "Word"
print (len (str1))
print (len (str2))
print (len (str3))
print (len (str4))

# Esercisio 8
n_sec = 60*60*24*365
print (n_sec)

# Esercizio 9
my_string = "I am studying Python"
print (my_string)
my_string_UP = my_string.upper ()
print (my_string_UP)
my_string_lo = my_string.lower ()
print (my_string_lo)
my_list = my_string.split ()
print (my_list)
my_list [3] = "a lot"
print (my_list)

# Esercizio 10
studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"]
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend"]
corsi.append ("Frontend")
corsi.append ("Cybersecurity")
print (studenti)
print (corsi)