# Indichiamo le queery neccassarie per testare e aggiornare le funzionalità del database.

-- Ipotizziamo di aver appena venduto 2 unità (QuantitaVenduta) 
-- del prodotto con ID 1 (ProdottoID) nel negozio con ID 3 (NegozioID)

# Query utile a verificare la disponibilità in magazzino di un prodotto
SELECT 
    p.NomeProdotto, 
    s.QuantitaDisponibile
FROM Scorte s
JOIN Prodotto p ON s.ProdottoID = p.ProdottoID
WHERE s.MagazzinoID = 1; -- L'ID del magazzino è una variabile che fa personalizzata per variare il test durante l'esecuzione del programma.

/* Query che simula la vendita di una determinata quantità del prodotto 1 (nell esempio 2 unità), 
il che fa calare la quantità di prodotto disponibile nel magazzino di riferimento del negozio indicato (Magazzino 3)*/
UPDATE Scorte
SET QuantitaDisponibile = QuantitaDisponibile - 2
WHERE ProdottoID = 1 
AND MagazzinoID = (
    SELECT MagazzinoID 
    FROM Negozio 
    WHERE NegozioID = 3
);

/* Query che controlla se le scorte in magazzino di un prodotto, appartenente ad una determinata categoria,
sono superio o meno alla soglia impostastata*/
SELECT 
    m.NomeMagazzino,
    p.NomeProdotto,
    c.NomeCategoria,
    s.QuantitaDisponibile AS Giacenza_Attuale,
    so.LivelloRestock AS Soglia_Minima,
    (so.LivelloRestock - s.QuantitaDisponibile) AS Pezzi_Mancanti
FROM Scorte s
JOIN Prodotto p ON s.ProdottoID = p.ProdottoID
JOIN Categoria c ON p.CategoriaID = c.CategoriaID
JOIN Magazzino m ON s.MagazzinoID = m.MagazzinoID
JOIN Soglia so ON c.CategoriaID = so.CategoriaID AND m.MagazzinoID = so.MagazzinoID
WHERE s.QuantitaDisponibile < so.LivelloRestock;

#-----------------------------------------------------------------
#-----------------------------------------------------------------
/* Questa query si occupa, in caso di necessitò, di ordinare quanto necessario per rifornire il determinato magazzino
del determinato prodotto appartenente alla specifica categoria*/

INSERT INTO Rifornimento (MagazzinoID, ProdottoID, QuantitaOrdinata, StatoOrdine)
VALUES (1, 2, 100, 'In elaborazione');