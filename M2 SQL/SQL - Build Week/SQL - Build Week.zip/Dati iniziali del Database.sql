#-----------------------------------------------------------------
# Popoliamo le tabelle.

-- 1. POPOLAMENTO CITTA
INSERT INTO Citta (NomeCitta) VALUES 
('Milano'), ('Roma'), ('Napoli'), ('Torino'), ('Palermo');

-- 2. POPOLAMENTO CATEGORIE
INSERT INTO Categoria (NomeCategoria) VALUES 
('Alimentari'), ('Elettronica'), ('Cura della Persona'), ('Casa e Pulizia'), ('Abbigliamento');

-- 3. POPOLAMENTO PRODOTTI (3 per categoria)
INSERT INTO Prodotto (NomeProdotto, CategoriaID, PrezzoListino) VALUES 
-- Alimentari (ID 1)
('Pasta Integrale 500g', 1, 1.20),
('Passata di Pomodoro 700g', 1, 0.95),
('Olio Extravergine 1L', 1, 8.50),
-- Elettronica (ID 2)
('Smartphone Modello X', 2, 599.00),
('Cuffie Bluetooth', 2, 45.00),
('Caricabatterie Rapido', 2, 19.90),
-- Cura della Persona (ID 3)
('Shampoo Antiforfora', 3, 3.50),
('Dentifricio Sbiancante', 3, 2.80),
('Sapone Liquido 500ml', 3, 1.50),
-- Casa e Pulizia (ID 4)
('Detersivo Lavatrice 2L', 4, 5.40),
('Sgrassatore Universale', 4, 2.20),
('Carta Igienica 4 rotoli', 4, 1.80),
-- Abbigliamento (ID 5)
('T-shirt Cotone Bianca', 5, 9.90),
('Jeans Denim Slim', 5, 39.90),
('Felpa con Cappuccio', 5, 29.90);

-- 4. POPOLAMENTO MAGAZZINI (3 hub principali)
INSERT INTO Magazzino (NomeMagazzino, CittaID) VALUES 
('Hub Nord', 1),   -- Milano
('Hub Centro', 2), -- Roma
('Hub Sud', 3);    -- Napoli

-- 5. POPOLAMENTO NEGOZI (Associati ai magazzini)
INSERT INTO Negozio (NomeNegozio, CittaID, MagazzinoID) VALUES 
('VendiCose Milano Duomo', 1, 1),
('VendiCose Torino Centro', 4, 1),
('VendiCose Roma Termini', 2, 2),
('VendiCose Roma Eur', 2, 2),
('VendiCose Napoli Porto', 3, 3),
('VendiCose Palermo Libertà', 5, 3);

-- 6. IMPOSTAZIONE SOGLIE (Regole di restock per Categoria/Magazzino)
-- Esempio: Il cibo a Milano ha soglie alte, l'elettronica a Napoli più basse.
INSERT INTO Soglia (CategoriaID, MagazzinoID, LivelloRestock) VALUES 
(1, 1, 100), (1, 2, 80), (1, 3, 90),  -- Alimentari
(2, 1, 20),  (2, 2, 15), (2, 3, 10),  -- Elettronica
(3, 1, 50),  (3, 2, 50), (3, 3, 50),  -- Cura Persona
(4, 1, 40),  (4, 2, 40), (4, 3, 40),  -- Casa
(5, 1, 30),  (5, 2, 25), (5, 3, 20);  -- Abbigliamento

-- 7. POPOLAMENTO SCORTE (Giacenze attuali)
-- Popoliamo solo alcuni prodotti per testare le query di "sotto soglia"
INSERT INTO Scorte (ProdottoID, MagazzinoID, QuantitaDisponibile) VALUES 
(1, 1, 120), (1, 2, 70),  -- Pasta: OK a Milano, SOTTO SOGLIA a Roma (70 < 80)
(4, 1, 18),  (4, 2, 25),  -- Smartphone: SOTTO SOGLIA a Milano (18 < 20)
(10, 1, 45), (10, 3, 35), -- Detersivo: OK a Milano, SOTTO SOGLIA a Napoli (35 < 40)
(13, 3, 15);              -- T-shirt: SOTTO SOGLIA a Napoli (15 < 20)

-- 8. ESEMPIO DI VENDITE (Per testare lo storico)
INSERT INTO Vendita (NegozioID, DataVendita) VALUES 
(1, '2023-10-25 10:30:00'),
(3, '2023-10-25 11:15:00'),
(5, '2023-10-25 12:00:00');

-- 9. DETTAGLIO VENDITE
INSERT INTO DettaglioVendita (VenditaID, ProdottoID, QuantitaVenduta, PrezzoApplicato) VALUES 
(1, 1, 2, 1.20), -- Milano vende 2 pacchi di pasta
(1, 5, 1, 45.00), -- Milano vende cuffie
(2, 4, 1, 599.00),-- Roma vende smartphone
(3, 13, 3, 9.90); -- Napoli vende 3 t-shirt

-- 10. RIFORNIMENTI IN CORSO
INSERT INTO Rifornimento (MagazzinoID, ProdottoID, QuantitaOrdinata, StatoOrdine) VALUES 
(1, 4, 50, 'In elaborazione'),
(2, 1, 200, 'Spedito');

#-----------------------------------------------------------------