#-----------------------------------------------------------------
# Creazione del Database
CREATE DATABASE VendiCose;
USE VendiCose;
#-----------------------------------------------------------------
#-----------------------------------------------------------------
# Creamo le tabelle, sono state divise in categorie in funzione dello scopo.

-- 1. TABELLE ANAGRAFICHE DI BASE
# Tabella delle categorie
CREATE TABLE Categoria (
    CategoriaID INT PRIMARY KEY AUTO_INCREMENT,
    NomeCategoria VARCHAR(100) NOT NULL
);

# Tabella delle cità, valida sia per i Magazzini sia per i Negozi
CREATE TABLE Citta (
    CittaID INT PRIMARY KEY AUTO_INCREMENT,
    NomeCitta VARCHAR(100) NOT NULL
);

-- 2. PRODOTTI E STRUTTURE FISICHE
# Tabella dei prodotti
CREATE TABLE Prodotto (
    ProdottoID INT PRIMARY KEY AUTO_INCREMENT,
    NomeProdotto VARCHAR(150) NOT NULL,
    CategoriaID INT,
    PrezzoListino DECIMAL(10, 2),
    FOREIGN KEY (CategoriaID) REFERENCES Categoria(CategoriaID)
);

# Tabella dei Magazzini
CREATE TABLE Magazzino (
    MagazzinoID INT PRIMARY KEY AUTO_INCREMENT,
    NomeMagazzino VARCHAR(100) NOT NULL,
    CittaID INT,
    FOREIGN KEY (CittaID) REFERENCES Citta(CittaID)
);

# Tabella dei Negozi
CREATE TABLE Negozio (
    NegozioID INT PRIMARY KEY AUTO_INCREMENT,
    NomeNegozio VARCHAR(100) NOT NULL,
    CittaID INT,
    MagazzinoID INT, -- Il magazzino che serve questo negozio
    FOREIGN KEY (CittaID) REFERENCES Citta(CittaID),
    FOREIGN KEY (MagazzinoID) REFERENCES Magazzino(MagazzinoID)
);

-- 3. LOGICA DI INVENTARIO E SOGLIE (RESTOCK)
# Tabella contentente il valore di rifornimento per le singole categorie e per il singolo magazzino
CREATE TABLE Soglia (
    SogliaID INT PRIMARY KEY AUTO_INCREMENT,
    CategoriaID INT NOT NULL,
    MagazzinoID INT NOT NULL,
    LivelloRestock INT NOT NULL,
    UNIQUE(CategoriaID, MagazzinoID), -- Impedisce doppie soglie per stessa cat/mag
    FOREIGN KEY (CategoriaID) REFERENCES Categoria(CategoriaID),
    FOREIGN KEY (MagazzinoID) REFERENCES Magazzino(MagazzinoID)
);

# Tabella relativa alle quantità immagazzinate nei singoli magazzini per prodotto
CREATE TABLE Scorte (
    ProdottoID INT NOT NULL,
    MagazzinoID INT NOT NULL,
    QuantitaDisponibile INT DEFAULT 0,
    PRIMARY KEY (ProdottoID, MagazzinoID),
    FOREIGN KEY (ProdottoID) REFERENCES Prodotto(ProdottoID),
    FOREIGN KEY (MagazzinoID) REFERENCES Magazzino(MagazzinoID)
);

-- 4. TRANSAZIONI E MOVIMENTI

# Tabella relativa a una vendita (composta da più prodotti appartententi a più categorie)
CREATE TABLE Vendita (
    VenditaID INT PRIMARY KEY AUTO_INCREMENT,
    NegozioID INT NOT NULL,
    DataVendita DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (NegozioID) REFERENCES Negozio(NegozioID)
);

# Tabella relativa alla vendida di un singolo prodotto
CREATE TABLE DettaglioVendita (
    DettaglioVID INT PRIMARY KEY AUTO_INCREMENT,
    VenditaID INT NOT NULL,
    ProdottoID INT NOT NULL,
    QuantitaVenduta INT NOT NULL,
    PrezzoApplicato DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (VenditaID) REFERENCES Vendita(VenditaID),
    FOREIGN KEY (ProdottoID) REFERENCES Prodotto(ProdottoID)
);

# Tabella relativa al riordino di un prodotto in base alla sua carenza nella relativa categoria
CREATE TABLE Rifornimento (
    RifornimentoID INT PRIMARY KEY AUTO_INCREMENT,
    MagazzinoID INT NOT NULL,
    ProdottoID INT NOT NULL,
    DataOrdine DATETIME DEFAULT CURRENT_TIMESTAMP,
    QuantitaOrdinata INT NOT NULL,
    StatoOrdine ENUM('In elaborazione', 'Spedito', 'Consegnato') DEFAULT 'In elaborazione',
    FOREIGN KEY (MagazzinoID) REFERENCES Magazzino(MagazzinoID),
    FOREIGN KEY (ProdottoID) REFERENCES Prodotto(ProdottoID)
);

#-----------------------------------------------------------------